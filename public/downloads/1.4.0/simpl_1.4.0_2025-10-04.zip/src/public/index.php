<?php

use app\Controllers\AppController;

// Load the start script
require_once '../app/Scripts/start.php';

// Make a new AppController object
new AppController();
