<?php

namespace app\Controllers;

class AppController
{
    public function __construct()
    {
        // new AlertController();
        new AuthController();
        // new AliasController();
    }
}
