<?php
// Mail configuration
const SITE_MAIL = 'support@example.com';
const NO_REPLY_MAIL = 'noreply@example.com';
