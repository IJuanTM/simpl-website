<?php
// Environment configuration
const DEV = true;

// Timezone configuration
const TIMEZONE = 'UTC';

// App configuration
const APP_NAME = 'Simpl';
const BASE_URL = 'http://simpl.local';

// Redirect configuration
const REDIRECT = 'home';
const ERROR_AUTO_REDIRECT = true;
