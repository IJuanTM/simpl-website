<?php

namespace app\Pages;

class HomePage
{
    //
}
